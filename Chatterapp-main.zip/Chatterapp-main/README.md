# Chatterapp
A simple chat app where thousands of people chat and discuss whatever they want this is a virtual heaven for people who like to be social and want a size that is easy to operate with and co-orperate with.
